exec QBM_PColumnChangeDataType 'CCCAzLocation', 'CCC_DisplayName', 'nvarchar(1000)'
go
exec QBM_PColumnDrop 'CCCAzLocation', 'CCC_Ident_AzLocation'
go

exec QBM_PColumnChangeDataType 'CCCAzMgmtGrp', 'CCC_DisplayName', 'nvarchar(1000)'
go
exec QBM_PColumnChangeDataType 'CCCAzMgmtGrp', 'CCC_Id', 'nvarchar(2000)'
go
exec QBM_PColumnChangeDataType 'CCCAzMgmtGrp', 'CCC_ResourceId', 'nvarchar(2000)'
go
exec QBM_PColumnDrop 'CCCAzMgmtGrp', 'CCC_Ident_AzMgmtGrp'
go
exec QBM_PColumnDrop 'CCCAzMgmtGrp', 'CCC_RiskIndexCalculated'
go

exec QBM_PColumnChangeDataType 'CCCAzResource', 'CCC_Id', 'nvarchar(2000)'
go
exec QBM_PColumnChangeDataType 'CCCAzResource', 'CCC_ResourceId', 'nvarchar(2000)'
go
exec QBM_PColumnDrop 'CCCAzResource', 'CCC_Ident_AzResource'
go

exec QBM_PColumnChangeDataType 'CCCAzResourceGroup', 'CCC_Id', 'nvarchar(2000)'
go
exec QBM_PColumnChangeDataType 'CCCAzResourceGroup', 'CCC_ResourceId', 'nvarchar(2000)'
go
exec QBM_PColumnDrop 'CCCAzResourceGroup', 'CCC_Ident_AzResourceGroup'
go
exec QBM_PColumnDrop 'CCCAzResourceGroup', 'CCC_RiskIndexCalculated'
go

exec QBM_PColumnDrop 'CCCAzResourceType', 'CCC_Ident_AzResourceType'
go

exec QBM_PColumnChangeDataType 'CCCAzRole', 'CCC_Id', 'nvarchar(2000)'
go
exec QBM_PColumnDrop 'CCCAzRole', 'CCC_Ident_AzRole'
go

exec QBM_PColumnChangeDataType 'CCCAzSubscription', 'CCC_Id', 'nvarchar(2000)'
go
exec QBM_PColumnChangeDataType 'CCCAzSubscription', 'CCC_ResourceId', 'nvarchar(2000)'
go
exec QBM_PColumnDrop 'CCCAzSubscription', 'CCC_Ident_AzSubscription'
go
exec QBM_PColumnDrop 'CCCAzSubscription', 'CCC_RiskIndexCalculated'
go
exec QBM_PColumnDrop 'CCCAzSubscription', 'CCC_UID_AADOrganization'
go

